<?php
session_start();

// Подключение к базе данных
require_once('config.php');

// Проверка, была ли отправлена форма
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Получение введенных пользователем данных
    $login = $_POST['login'];
    $password = $_POST['password'];

    // Подключение к базе данных
    $db = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

    // Проверка соединения
    if ($db->connect_error) {
        die('Ошибка подключения к базе данных: ' . $db->connect_error);
    }

    // Подготовка запроса для поиска пользователя по логину
    $stmt = $db->prepare('SELECT * FROM users WHERE login = ?');
    $stmt->bind_param('s', $login);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Проверка пароля
        if (password_verify($password, $user['password'])) {
            // Авторизация успешна
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $stmt->close();
            $db->close();

            // Перенаправление на домашнюю страницу после успешной авторизации
            header('Location: dashboard.php');
            exit();
        } else {
            // Неправильный пароль
            $_SESSION['login_error'] = 'Неправильный пароль.';
        }
    } else {
        // Пользователь не найден
        $_SESSION['login_error'] = 'Пользователь не найден.';
    }

    $stmt->close();
    $db->close();

    // Перенаправление на страницу входа после ошибки авторизации
    header('Location: login.php');
    exit();
} else {
    // Если форма не была отправлена, перенаправление на страницу входа
    header('Location: login.php');
    exit();
}
?>
