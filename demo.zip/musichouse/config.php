<?php
define('DB_HOST', 'localhost'); // Адрес сервера базы данных
define('DB_USERNAME', 'root'); // Имя пользователя базы данных
define('DB_PASSWORD', ''); // Пароль пользователя базы данных
define('DB_NAME', 'music'); // Имя базы данных

// Создание подключения к базе данных
$connection = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Проверка успешного подключения
if (!$connection) {
    die("Ошибка подключения к базе данных: " . mysqli_connect_error());
}
?>