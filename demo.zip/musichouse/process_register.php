<?php
// Подключение файла config.php 

// Проверка, отправки формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Получение данных из формы
  $name = $_POST['name'];
  $surname = $_POST['surname'];
  $patronymic = $_POST['patronymic'];
  $login = $_POST['login'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $password_repeat = $_POST['password_repeat'];
  $rules = isset($_POST['rules']) ? $_POST['rules'] : '';

  // Проверка обязательных полей
  if (empty($name) || empty($surname) || empty($login) || empty($email) || empty($password) || empty($password_repeat)) {
    echo "Пожалуйста, заполните все обязательные поля.";
    exit;
  }

  // Проверка совпадения паролей
  if ($password !== $password_repeat) {
    echo "Пароли не совпадают.";
    exit;
  }

  // Проверка валидности email-адреса
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    // Некорректный email-адрес, такой уже существует.
    $errorMessage = 'Существующий в базе email-адрес. Измените email-адрес и попробуйте снова.';
    // ...
  } else {
    // если Email-адрес корректен, продолжаем обработку данных и регистрацию пользователя
     
    // Перенаправление пользователя на основе результата регистрации
    if ($isRegistered) {
      // Регистрация успешна
      header('Location: login.php'); // Перенаправление на страницу авторизации после успешной регистрации
      exit();
    } else {
      // Ошибка регистрации
      $errorMessage = 'Произошла ошибка при регистрации. Попробуйте снова.';
      // ...
    }
  }


  // Хеширование пароля
  $hashed_password = password_hash($password, PASSWORD_DEFAULT);

  // Создание подключения к базе данных (используйте свои настройки)
  $conn = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

  // Проверка соединения
  if (!$conn) {
    die("Ошибка подключения к базе данных: " . mysqli_connect_error());
  }

  // Подготовка SQL-запроса для вставки данных в таблицу пользователей
  $sql = "INSERT INTO users (name, surname, patronymic, login, email, password) VALUES (?, ?, ?, ?, ?, ?)";

  // Создание подготовленного выражения
  $stmt = mysqli_prepare($conn, $sql);
  mysqli_stmt_bind_param($stmt, "ssssss", $name, $surname, $patronymic, $login, $email, $hashed_password);

  // Выполнение подготовленного выражения
  if (mysqli_stmt_execute($stmt)) {
    echo "Регистрация успешна. Можете войти на сайт.";
    // Перенаправление на страницу авторизации после успешной регистрации
    header('Location: login.php');
    exit();
  } else {
    echo "Произошла ошибка при регистрации. Попробуйте снова." . mysqli_error($conn);
  }

  // Закрытие подключения к базе данных
  mysqli_stmt_close($stmt);
  mysqli_close($conn);

}
?>
