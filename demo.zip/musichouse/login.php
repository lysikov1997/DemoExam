<?php
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получение данных из формы авторизации
    $login = $_POST['login'];
    $password = $_POST['password'];

    // Подключение к базе данных
    $db = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

    // Проверка соединения
    if ($db->connect_error) {
        die('Ошибка подключения к базе данных: ' . $db->connect_error);
    }

    // Подготовка запроса для поиска пользователя по логину
    $stmt = $db->prepare('SELECT * FROM users WHERE login = ?');
    $stmt->bind_param('s', $login);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Проверка пароля
        if (password_verify($password, $user['password'])) {
            // Авторизация успешна
            $_SESSION['user_id'] = $user['id'];
            $stmt->close();
            $db->close();
            header('Location: dashboard.php'); // Редирект на страницу после успешной авторизации
            exit();
        }
    }

    // Неверный логин или пароль
    $_SESSION['error'] = 'Неверный логин или пароль';
    $stmt->close();
    $db->close();
}

// Вывод ошибок авторизации
if (isset($_SESSION['error'])) {
    $error = $_SESSION['error'];
    unset($_SESSION['error']);
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Вход</title>
  <!-- Подключение Bootstrap CSS -->
  <link rel="stylesheet" href="../resourse/bootstrap-5.0.2-dist/css/bootstrap.min.css">
</head>

<body><!-- Pills navs -->

<?php if (isset($error)) : ?>
        <p><?php echo $error; ?></p>
    <?php endif; ?>
    
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-md-6">
                <h2 class="text-center mb-4">Авторизация</h2>

                <?php if (isset($_SESSION['login_error'])): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $_SESSION['login_error']; ?>
                    </div>
                    <?php unset($_SESSION['login_error']); ?>
                <?php endif; ?>

                <form action="process_login.php" method="POST">
                    <div class="mb-3">
                        <label for="login" class="form-label">Логин</label>
                        <input type="text" class="form-control" id="login" name="login" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Пароль</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="text-center gap-2">
                        <button type="submit" class="btn btn-dark btn-lg">Войти</button>
                        <button type="button" class="btn btn-dark btn-sm" onclick="goBack()">Назад</button>
                    </div>
                    
                </form>
            </div>
        </div>
    </div>


    <script>
function goBack() {
  window.history.back();
}
</script>
</body>

</html>
<!-- Pills content -->