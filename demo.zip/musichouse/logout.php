<?php
session_start();

// Удаление всех сессионных данных
session_unset();

// Уничтожение сессии
session_destroy();

// Перенаправление на страницу входа после выхода
header('Location: index.html');
exit();
?>
