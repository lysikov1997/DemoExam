<?php
session_start();

// Подключение к базе данных
require_once('config.php');


// Проверка, авторизован ли пользователь
if (!isset($_SESSION['user_id'])) {
    // Если пользователь не авторизован, перенаправляем на страницу авторизации
    header('Location: login.php');
    exit;
}

// Получаем информацию о текущем пользователе
$user_id = $_SESSION['user_id'];

// Создание соединения
$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Проверка соединения
if ($conn->connect_error) {
    die('Ошибка подключения к базе данных: ' . $conn->connect_error);
}

// Запрос для получения информации о пользователе
$sql = "SELECT * FROM users WHERE id = $user_id";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $name = $row['name'];
    $email = $row['email'];

    // Вывод информации о пользователе
    $user_info = "Имя: $name<br>Email: $email";
} else {
    // Если пользователь не найден или произошла ошибка, то значения по умолчанию
    $user_info = 'Имя: Неизвестно<br>Email: Неизвестно';
}

// Закрытие соединения
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет</title>
    <!-- Подключение Bootstrap CSS -->
    <link rel="stylesheet" href="resourse/bootstrap-5.0.2-dist/css/bootstrap.min.css">
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="#">
        <img src="img/logo.png" alt="Логотип компании"  width="143" height="50">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            <a class="nav-link active" href="index.html">О нас</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="catalog.html">Каталог</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="location.html">Где нас найти</a>
        </li>
      </ul>
      
      <form class="d-flex ms-auto">
      <button class="btn btn-dark me-2" type="submit" formaction="katalog.php">Корзина</button>
    <button class="btn btn-dark me-2" type="submit" formaction="logout.php">Выйти</button>
      </form>
    </div>
  </nav>

   



<div class="container mt-4">
    <div class="row" id="product row-1">
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="img/guitar1.jpeg" class="card-img-top" alt="Product 1">
          <div class="card-body">
            <h5 class="card-title">Гитара P-1000</h5>
            <p class="card-text">Цена: 10000</p>
            <a href="product.html" class="btn btn-dark">Подробнее</a>
            <a href="#" class="btn btn-dark">В корзину</a>
          </div>
        </div>
      </div>

      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="img/guitar2.jpeg" class="card-img-top" alt="Product 2">
          <div class="card-body">
            <h5 class="card-title">Гитара P-2000</h5>
            <p class="card-text">Цена: 10000</p>
            <a href="product.html" class="btn btn-dark">Подробнее</a>
            <a href="#" class="btn btn-dark">В корзину</a>
          </div>
        </div>
      </div>
      
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="img/guitar3.jpeg" class="card-img-top" alt="Product 3">
          <div class="card-body">
            <h5 class="card-title">Гитара P-3000</h5>
            <p class="card-text">Цена: 10000</p>
            <a href="product1.html" class="btn btn-dark">Подробнее</a>
            <a href="#" class="btn btn-dark">В корзину</a>
          </div>
        </div>
      </div>

      <!-- Добавьте больше карточек товаров здесь -->

    </div>
    <div class="row" id="product row-2">
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="img/guitar4.jpeg" class="card-img-top" alt="Product 4">
          <div class="card-body">
            <h5 class="card-title">Гитара P-4000</h5>
            <p class="card-text">Цена: 10000</p>
            <a href="product1.html" class="btn btn-dark">Подробнее</a>
            <a href="#" class="btn btn-dark">В корзину</a>
          </div>
        </div>
      </div>

      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="img/guitar5.jpeg" class="card-img-top" alt="Product 5">
          <div class="card-body">
            <h5 class="card-title">Гитара P-5000</h5>
            <p class="card-text">Цена: 10000</p>
            <a href="product1.html" class="btn btn-dark">Подробнее</a>
            <a href="#" class="btn btn-dark">В корзину</a>
          </div>
        </div>
      </div>
      
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="img/guitar6.jpeg" class="card-img-top" alt="Product 6">
          <div class="card-body">
            <h5 class="card-title">Гитара P-6000</h5>
            <p class="card-text">Цена: 10000</p>
            <a href="product1.html" class="btn btn-dark">Подробнее</a>
            <a href="#" class="btn btn-dark">В корзину</a>
          </div>
        </div>
      </div>

      <!-- Добавьте больше карточек товаров здесь -->

    </div>
    <div class="row" id="product row-3">
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="img/piano1.jpeg" class="card-img-top" alt="Product 7">
          <div class="card-body">
            <h5 class="card-title">Пианино G-7000</h5>
            <p class="card-text">Цена: 20000</p>
            <a href="product1.html" class="btn btn-dark">Подробнее</a>
            <a href="#" class="btn btn-dark">В корзину</a>
          </div>
        </div>
      </div>

      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="img/piano5.png" class="card-img-top" alt="Product 8">
          <div class="card-body">
            <h5 class="card-title">Пианино G-8000</h5>
            <p class="card-text">Цена: 20000</p>
            <a href="product1.html" class="btn btn-dark">Подробнее</a>
            <a href="#" class="btn btn-dark">В корзину</a>
          </div>
        </div>
      </div>
      
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="img/piano3.jpeg" class="card-img-top" alt="Product 9">
          <div class="card-body">
            <h5 class="card-title">Пианино G-9000</h5>
            <p class="card-text">Цена: 20000</p>
            <a href="product1.html" class="btn btn-dark">Подробнее</a>
            <a href="#" class="btn btn-dark">В корзину</a>
          </div>
        </div>
      </div>

    </div>
    <div class="row" id="product row-4">
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="img/violin2.jpeg" class="card-img-top" alt="Product 10">
          <div class="card-body">
            <h5 class="card-title">Скрипка T-1075</h5>
            <p class="card-text">Цена: 15000</p>
            <a href="product1.html" class="btn btn-dark">Подробнее</a>
            <a href="#" class="btn btn-dark">В корзину</a>
          </div>
        </div>
      </div>

      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="img/violin3.jpeg" class="card-img-top" alt="Product 11">
          <div class="card-body">
            <h5 class="card-title">Скрипка T-1075</h5>
            <p class="card-text">Цена: 15000</p>
            <a href="product1.html" class="btn btn-dark">Подробнее</a>
            <a href="#" class="btn btn-dark">В корзину</a>
          </div>
        </div>
      </div>
      
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="img/violin4.jpeg" class="card-img-top" alt="Product 12">
          <div class="card-body">
            <h5 class="card-title">Скрипка T-1075</h5>
            <p class="card-text">Цена: 15000</p>
            <a href="product1.html" class="btn btn-dark">Подробнее</a>
            <a href="#" class="btn btn-dark">В корзину</a>
          </div>
        </div>
      </div>

      <!-- Добавьте больше карточек товаров здесь -->

    </div>
  </div>


    <!-- Подключение Bootstrap JS -->
    <script src="resourse/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
